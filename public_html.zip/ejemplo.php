<?php
    include('menu.php')
?>
    
    <h1>pagina de prueba</h1>