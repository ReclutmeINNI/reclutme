<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reclut.me</title>
    <link rel="stylesheet" href="css/estilos-menuempleo.css">
    
</head>
<body>

<a href=https://reclut.me/empnuevo.php><button class="button" >Agregar empleo</button></a> 
<a href=https://reclut.me/empleos.php><button class="button2" >Ver empleos</button></a> 
<a href=https://reclut.me/empnuevo.php><button class="button1" >Editar empleo</button></a> 
<a href=https://reclut.me/empnuevo.php><button class="button2" >Eliminar empleo</button></a> 

</body>
</html>  