<?php
include('menu1.php');

?>
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reclut.me/Usuarios</title>
    <link rel="stylesheet" href="css/estilos-menuempleo.css">
   
    
</head>
<body>

<a href=https://reclut.me/empnuevo.php><button class="button  button1" >Agregar Usuario</button></a> 
<a href=https://reclut.me/empleos.php><button class="button button2" >Ver Usuarioss</button></a> 
<a href=https://reclut.me/modificarempleo.php> <button class="button button3" >Modificar o eliminar Usuario</button></a> 
<!--<a href=https://reclut.me/modificarempleo.php><button class="button button4" >Eliminar empleo</button></a> -->

</body>
</html>   